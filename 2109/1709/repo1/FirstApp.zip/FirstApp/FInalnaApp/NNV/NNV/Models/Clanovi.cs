﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;


namespace NNV.Models
{
    [Table(name: "Clanovi")]
    public class Clanovi
    {
        [Key]
        public int ID_Clana { get; set; }
        public string Ime_i_prezime { get; set; }
        public string Email { get; set; }
        public bool Status { get; set; }


        [Required(ErrorMessage = "Унесите корисничко име")]

        [Display(Name = "Корисничко име:") ]
        [StringLength(30)]
        public string Korisnicko_ime { get; set; }

        [Required(ErrorMessage = "Унесите лозинку")]
        [DataType(DataType.Password)]
        [Display(Name = "Лозинка:")]
        [StringLength(10)]
        public string Lozinka { get; set; }
        public virtual ICollection<Prisustvo> Prisustvos { get; set; }
    }
}